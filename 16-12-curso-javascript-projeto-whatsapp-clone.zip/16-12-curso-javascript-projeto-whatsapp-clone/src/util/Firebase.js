const firebase = require('@firebase/app').default;
require('@firebase/firestore');

export class Firebase{

    constructor() {

        
        this._config = {
            apiKey: "AIzaSyDoSbydzw7qjd-yhYG0NvCdnnB0biCUzKw",
            authDomain: "whatsapp-clone-67f9e.firebaseapp.com",
            projectId: "whatsapp-clone-67f9e",
            storageBucket: "whatsapp-clone-67f9e.appspot.com",
            messagingSenderId: "167417412182",
            appId: "1:167417412182:web:9f7ddbd0f0bac4cd71d9f7"
          };

          this.init();
    }

    init() {

        if (!this._initialized) {

            firebase.initializeApp(this._config);

            firebase.firestore().settings({
                timestampsInSnapshots: true
            });

            this._initialized = true;

        }
          
          
    }

    static db() {

        return firebase.firestore();
    }

    static hd() {

        return firebase.storage();

    }

    initAuth() {

        return new Promise((s, f) => {

            let provider = new firebase.auth.GoogleAuthProvider();
            firebase.auth().signInWithPopup(provider).then((result) => {
                
                let token = result.credential.acessToken;
                let user = result.user;

                s(user, token);

            }).catch((err) => {
                f(err);
            });

        });
    }
}